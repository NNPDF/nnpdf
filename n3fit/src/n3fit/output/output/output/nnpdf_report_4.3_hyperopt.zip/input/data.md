% Data-theory comparison for {@dataset_name@}
# Absolute
{@plot_fancy_dataspecs@}
# Normalized
{@Datanorm plot_fancy_dataspecs@}
