%NNPDF report comparing {@ current fit @} and {@ reference fit @}

# Luminosity plots

{@with Normalize@}
{@with lumi_channels@}
{@plot_lumi1d@}
{@endwith@}
{@endwith@}
